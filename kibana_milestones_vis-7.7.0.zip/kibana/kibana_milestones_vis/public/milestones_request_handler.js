"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.createMilestonesRequestHandler = createMilestonesRequestHandler;

var _services = require("../../../src/plugins/data/public/services");

var _public = require("../../../src/plugins/data/public");

var _constants = require("./constants");

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(source, true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(source).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function createMilestonesRequestHandler(_ref) {
  var uiSettings = _ref.core.uiSettings;

  var esClient = (0, _services.getSearchService)().__LEGACY.esClient;

  return (
    /*#__PURE__*/
    function () {
      var _ref2 = _asyncToGenerator(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee(_ref3) {
        var index, timeRange, filters, query, visParams, indexPatternTitle, esQueryConfigs, filtersDsl, request, resp;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                index = _ref3.index, timeRange = _ref3.timeRange, filters = _ref3.filters, query = _ref3.query, visParams = _ref3.visParams;
                indexPatternTitle = index.title;
                esQueryConfigs = _public.esQuery.getEsQueryConfig(uiSettings);
                filtersDsl = _public.esQuery.buildEsQuery(undefined, query, filters, esQueryConfigs);

                if (!(visParams.labelField === undefined || visParams.labelField === _constants.NONE_SELECTED)) {
                  _context.next = 6;
                  break;
                }

                return _context.abrupt("return", {
                  timeFieldName: index.timeFieldName,
                  data: []
                });

              case 6:
                request = {
                  index: indexPatternTitle,
                  body: {
                    query: {
                      bool: {
                        must: [filtersDsl, {
                          range: _defineProperty({}, index.timeFieldName, {
                            gte: timeRange.from,
                            lt: timeRange.to
                          })
                        }]
                      }
                    },
                    _source: [visParams.labelField].concat(_toConsumableArray(visParams.categoryField !== undefined && visParams.categoryField !== _constants.NONE_SELECTED ? [visParams.categoryField] : [])),
                    script_fields: {
                      milestones_timestamp: {
                        script: {
                          source: "doc[\"".concat(index.timeFieldName, "\"].value.millis")
                        }
                      }
                    },
                    size: visParams.maxDocuments,
                    sort: [_defineProperty({}, visParams.sortField, {
                      "order": visParams.sortOrder
                    })]
                  }
                };
                _context.next = 9;
                return esClient.search(request);

              case 9:
                resp = _context.sent;
                return _context.abrupt("return", {
                  timeFieldName: index.timeFieldName,
                  data: resp.hits.hits.map(function (hit) {
                    return _objectSpread({
                      timestamp: hit.fields.milestones_timestamp[0],
                      text: hit._source[visParams.labelField]
                    }, visParams.categoryField !== undefined && visParams.category !== _constants.NONE_SELECTED ? {
                      category: hit._source[visParams.categoryField]
                    } : {});
                  })
                });

              case 11:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref2.apply(this, arguments);
      };
    }()
  );
}